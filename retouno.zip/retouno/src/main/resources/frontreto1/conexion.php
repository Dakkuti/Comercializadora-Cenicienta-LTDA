<?php
$db = mysqli_connect("localhost", "root", "", "reto1ciclo4", 3308);

session_start();
/*
if($db){
    echo'Conectado exitosamente a la base de datos';
} else {
    echo 'No se ha podido conectar';
}
?>*/